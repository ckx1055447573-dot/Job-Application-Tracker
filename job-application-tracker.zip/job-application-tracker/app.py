import sqlite3
from datetime import date
from pathlib import Path

import pandas as pd
import streamlit as st

DB_PATH = Path("data/applications.db")
DB_PATH.parent.mkdir(exist_ok=True)

STATUSES = ["Applied", "Interview", "Rejected", "Offer", "No Response"]
STATUS_EMOJI = {
    "Applied": "📨",
    "Interview": "🎤",
    "Rejected": "❌",
    "Offer": "🎉",
    "No Response": "⏳",
}


def get_connection():
    return sqlite3.connect(DB_PATH)


def init_db():
    with get_connection() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS applications (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                company TEXT NOT NULL,
                position TEXT NOT NULL,
                status TEXT NOT NULL,
                applied_date TEXT NOT NULL,
                job_url TEXT,
                notes TEXT
            )
            """
        )
        conn.commit()


def add_application(company, position, status, applied_date, job_url, notes):
    with get_connection() as conn:
        conn.execute(
            """
            INSERT INTO applications
            (company, position, status, applied_date, job_url, notes)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (company, position, status, applied_date, job_url, notes),
        )
        conn.commit()


def load_applications():
    with get_connection() as conn:
        return pd.read_sql_query(
            """
            SELECT id, company, position, status, applied_date, job_url, notes
            FROM applications
            ORDER BY applied_date DESC, id DESC
            """,
            conn,
        )


def delete_application(application_id):
    with get_connection() as conn:
        conn.execute("DELETE FROM applications WHERE id = ?", (application_id,))
        conn.commit()


def update_status(application_id, status):
    with get_connection() as conn:
        conn.execute(
            "UPDATE applications SET status = ? WHERE id = ?",
            (status, application_id),
        )
        conn.commit()


st.set_page_config(
    page_title="Job Application Tracker",
    page_icon="📊",
    layout="wide",
)

init_db()

st.title("📊 Job Application Tracker")
st.caption("A simple dashboard for tracking job applications and analyzing your job search.")

df = load_applications()

# Sidebar
with st.sidebar:
    st.header("➕ Add Application")

    with st.form("add_application_form", clear_on_submit=True):
        company = st.text_input("Company *", placeholder="e.g. IBM")
        position = st.text_input("Position *", placeholder="e.g. SAP Analyst")
        status = st.selectbox("Status", STATUSES)
        applied_date = st.date_input("Application Date", value=date.today())
        job_url = st.text_input("Job URL", placeholder="https://...")
        notes = st.text_area("Notes", placeholder="Recruiter, salary range, interview notes...")

        submitted = st.form_submit_button("Add Application", use_container_width=True)

        if submitted:
            if not company.strip() or not position.strip():
                st.error("Company and Position are required.")
            else:
                add_application(
                    company.strip(),
                    position.strip(),
                    status,
                    applied_date.isoformat(),
                    job_url.strip(),
                    notes.strip(),
                )
                st.success("Application added!")
                st.rerun()

# Metrics
total = len(df)
interviews = int((df["status"] == "Interview").sum()) if total else 0
offers = int((df["status"] == "Offer").sum()) if total else 0
rejected = int((df["status"] == "Rejected").sum()) if total else 0
response_rate = ((interviews + offers + rejected) / total * 100) if total else 0

col1, col2, col3, col4 = st.columns(4)
col1.metric("Total Applications", total)
col2.metric("Interviews", interviews)
col3.metric("Offers", offers)
col4.metric("Response Rate", f"{response_rate:.1f}%")

st.divider()

if total == 0:
    st.info("No applications yet. Add your first application using the sidebar.")
else:
    left, right = st.columns(2)

    with left:
        st.subheader("📌 Application Status")
        status_counts = df["status"].value_counts().reindex(STATUSES, fill_value=0)
        st.bar_chart(status_counts)

    with right:
        st.subheader("📅 Applications Over Time")
        daily_counts = (
            df.assign(applied_date=pd.to_datetime(df["applied_date"]))
            .groupby("applied_date")
            .size()
        )
        st.line_chart(daily_counts)

    st.divider()

    st.subheader("📋 Application List")

    filter_col1, filter_col2, filter_col3 = st.columns(3)

    with filter_col1:
        status_filter = st.multiselect(
            "Filter by Status",
            STATUSES,
            default=STATUSES,
        )

    with filter_col2:
        company_filter = st.text_input("Search Company")

    with filter_col3:
        position_filter = st.text_input("Search Position")

    filtered_df = df[df["status"].isin(status_filter)].copy()

    if company_filter:
        filtered_df = filtered_df[
            filtered_df["company"].str.contains(company_filter, case=False, na=False)
        ]

    if position_filter:
        filtered_df = filtered_df[
            filtered_df["position"].str.contains(position_filter, case=False, na=False)
        ]

    st.write(f"Showing **{len(filtered_df)}** application(s).")

    for _, row in filtered_df.iterrows():
        status_icon = STATUS_EMOJI.get(row["status"], "📌")

        with st.expander(
            f"{status_icon} {row['company']} — {row['position']} | {row['status']}"
        ):
            info_col1, info_col2 = st.columns(2)

            with info_col1:
                st.write(f"**Applied:** {row['applied_date']}")
                st.write(f"**Status:** {row['status']}")
                if row["job_url"]:
                    st.link_button("🔗 Open Job Posting", row["job_url"])

            with info_col2:
                st.write("**Notes:**")
                st.write(row["notes"] or "No notes.")

            action_col1, action_col2 = st.columns([3, 1])

            with action_col1:
                new_status = st.selectbox(
                    "Update Status",
                    STATUSES,
                    index=STATUSES.index(row["status"]),
                    key=f"status_{row['id']}",
                )
                if new_status != row["status"]:
                    update_status(row["id"], new_status)
                    st.success("Status updated.")
                    st.rerun()

            with action_col2:
                st.write("")
                st.write("")
                if st.button("🗑️ Delete", key=f"delete_{row['id']}"):
                    delete_application(int(row["id"]))
                    st.rerun()

    st.divider()

    csv_data = filtered_df.to_csv(index=False).encode("utf-8")
    st.download_button(
        "⬇️ Export Applications as CSV",
        data=csv_data,
        file_name="job_applications.csv",
        mime="text/csv",
    )
