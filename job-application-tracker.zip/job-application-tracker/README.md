# 📊 Job Application Tracker

A simple job application tracking dashboard built with **Python**, **SQLite**, **Pandas**, and **Streamlit**.

This project helps job seekers track applications, monitor application statuses, and analyze job search activity through a simple dashboard.

## 🚀 Features

- Add job applications
- Track application status
- Store company and position information
- Save job posting URLs
- Add notes
- View application statistics
- Filter applications by status
- Search by company or position
- Update application status
- Delete applications
- Export application data to CSV
- SQLite database for persistent local storage

## 📈 Dashboard Metrics

The dashboard calculates:

- Total Applications
- Total Interviews
- Total Offers
- Response Rate

## 🛠️ Tech Stack

- **Python** — Application logic
- **Streamlit** — Web interface
- **SQLite** — Local database
- **Pandas** — Data analysis and filtering

## 📂 Project Structure

```text
job-application-tracker/
│
├── app.py
├── requirements.txt
├── README.md
├── .gitignore
│
└── data/
    └── applications.db
```

## 💻 Installation

### 1. Clone the repository

```bash
git clone https://github.com/YOUR_USERNAME/job-application-tracker.git
cd job-application-tracker
```

### 2. Create a virtual environment

```bash
python -m venv venv
```

Activate it:

**Windows:**

```bash
venv\Scripts\activate
```

**Mac/Linux:**

```bash
source venv/bin/activate
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Run the application

```bash
streamlit run app.py
```

The application will open in your browser.

## 🧠 What I Learned

Through this project, I practiced:

- Designing a simple relational database
- Performing CRUD operations with SQLite
- Building a data dashboard
- Creating KPI metrics
- Filtering and analyzing data with Pandas
- Building a user interface with Streamlit
- Exporting data to CSV

## 🔮 Future Improvements

Potential future features:

- User authentication
- PostgreSQL database
- Email reminder system
- Interview scheduling
- Salary tracking
- Application response time analysis
- Job market analytics
- Cloud deployment

## 📌 Project Purpose

This project was created as a practical business application to demonstrate basic skills in:

**Data Analysis · Database Management · Business Process Tracking · Dashboard Development**

---

Built with Python and Streamlit.
